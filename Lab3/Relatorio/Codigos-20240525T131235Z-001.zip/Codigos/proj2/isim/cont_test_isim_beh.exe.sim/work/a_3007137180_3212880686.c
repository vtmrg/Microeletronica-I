/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/lfilus/Lab_3/proj2/trab3_proj2.vhd";



static void work_a_3007137180_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    int t14;
    int t15;
    char *t16;

LAB0:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1152U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4768);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(26, ng0);
    t4 = (t0 + 2152U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 1512U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 != t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 2608U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    *((int *)t2) = 0;

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(27, ng0);
    t4 = (t0 + 2608U);
    t13 = *((char **)t4);
    t14 = *((int *)t13);
    t15 = (t14 + 1);
    t4 = (t0 + 2608U);
    t16 = *((char **)t4);
    t4 = (t16 + 0);
    *((int *)t4) = t15;
    xsi_set_current_line(28, ng0);
    t2 = (t0 + 2608U);
    t4 = *((char **)t2);
    t14 = *((int *)t4);
    t1 = (t14 == 50000);
    if (t1 != 0)
        goto LAB11;

LAB13:
LAB12:    goto LAB9;

LAB11:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 1512U);
    t5 = *((char **)t2);
    t3 = *((unsigned char *)t5);
    t2 = (t0 + 4880);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t16 = *((char **)t13);
    *((unsigned char *)t16) = t3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(30, ng0);
    t2 = (t0 + 2608U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    *((int *)t2) = 0;
    goto LAB12;

}

static void work_a_3007137180_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    int t18;
    int t19;
    char *t20;

LAB0:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;

LAB3:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t18 = *((int *)t2);
    t1 = (t0 + 4944);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    *((int *)t14) = t18;
    xsi_driver_first_trans_fast(t1);
    t1 = (t0 + 4784);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 2112U);
    t6 = xsi_signal_has_event(t1);
    if (t6 == 1)
        goto LAB8;

LAB9:    t5 = (unsigned char)0;

LAB10:    if (t5 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(44, ng0);
    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)3);
    if (t13 != 0)
        goto LAB11;

LAB13:
LAB12:    goto LAB6;

LAB8:    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t5 = t10;
    goto LAB10;

LAB11:    xsi_set_current_line(45, ng0);
    t7 = (t0 + 1672U);
    t14 = *((char **)t7);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)3);
    if (t16 != 0)
        goto LAB14;

LAB16:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t18 = *((int *)t2);
    t19 = (t18 - 1);
    t1 = (t0 + 2728U);
    t7 = *((char **)t1);
    t1 = (t7 + 0);
    *((int *)t1) = t19;
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t18 = *((int *)t2);
    t19 = (-(1));
    t3 = (t18 == t19);
    if (t3 != 0)
        goto LAB20;

LAB22:
LAB21:
LAB15:    goto LAB12;

LAB14:    xsi_set_current_line(46, ng0);
    t7 = (t0 + 2728U);
    t17 = *((char **)t7);
    t18 = *((int *)t17);
    t19 = (t18 + 1);
    t7 = (t0 + 2728U);
    t20 = *((char **)t7);
    t7 = (t20 + 0);
    *((int *)t7) = t19;
    xsi_set_current_line(47, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t18 = *((int *)t2);
    t3 = (t18 == 10);
    if (t3 != 0)
        goto LAB17;

LAB19:
LAB18:    goto LAB15;

LAB17:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2728U);
    t7 = *((char **)t1);
    t1 = (t7 + 0);
    *((int *)t1) = 0;
    goto LAB18;

LAB20:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 2728U);
    t7 = *((char **)t1);
    t1 = (t7 + 0);
    *((int *)t1) = 9;
    goto LAB21;

}

static void work_a_3007137180_3212880686_p_2(char *t0)
{
    char *t1;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(63, ng0);

LAB3:    t1 = (t0 + 7292);
    t3 = (t0 + 5008);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3007137180_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned char t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    unsigned char t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    int t23;
    unsigned char t24;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    int t33;
    unsigned char t34;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    int t43;
    unsigned char t44;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    int t53;
    unsigned char t54;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    int t63;
    unsigned char t64;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    int t73;
    unsigned char t74;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    int t83;
    unsigned char t84;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;

LAB0:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t4 = (t3 == 0);
    if (t4 != 0)
        goto LAB3;

LAB4:    t11 = (t0 + 2312U);
    t12 = *((char **)t11);
    t13 = *((int *)t12);
    t14 = (t13 == 1);
    if (t14 != 0)
        goto LAB5;

LAB6:    t21 = (t0 + 2312U);
    t22 = *((char **)t21);
    t23 = *((int *)t22);
    t24 = (t23 == 2);
    if (t24 != 0)
        goto LAB7;

LAB8:    t31 = (t0 + 2312U);
    t32 = *((char **)t31);
    t33 = *((int *)t32);
    t34 = (t33 == 3);
    if (t34 != 0)
        goto LAB9;

LAB10:    t41 = (t0 + 2312U);
    t42 = *((char **)t41);
    t43 = *((int *)t42);
    t44 = (t43 == 4);
    if (t44 != 0)
        goto LAB11;

LAB12:    t51 = (t0 + 2312U);
    t52 = *((char **)t51);
    t53 = *((int *)t52);
    t54 = (t53 == 5);
    if (t54 != 0)
        goto LAB13;

LAB14:    t61 = (t0 + 2312U);
    t62 = *((char **)t61);
    t63 = *((int *)t62);
    t64 = (t63 == 6);
    if (t64 != 0)
        goto LAB15;

LAB16:    t71 = (t0 + 2312U);
    t72 = *((char **)t71);
    t73 = *((int *)t72);
    t74 = (t73 == 7);
    if (t74 != 0)
        goto LAB17;

LAB18:    t81 = (t0 + 2312U);
    t82 = *((char **)t81);
    t83 = *((int *)t82);
    t84 = (t83 == 8);
    if (t84 != 0)
        goto LAB19;

LAB20:
LAB21:    t91 = (t0 + 7359);
    t93 = (t0 + 5072);
    t94 = (t93 + 56U);
    t95 = *((char **)t94);
    t96 = (t95 + 56U);
    t97 = *((char **)t96);
    memcpy(t97, t91, 7U);
    xsi_driver_first_trans_fast_port(t93);

LAB2:    t98 = (t0 + 4800);
    *((int *)t98) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 7296);
    t6 = (t0 + 5072);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 7U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB2;

LAB5:    t11 = (t0 + 7303);
    t16 = (t0 + 5072);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t11, 7U);
    xsi_driver_first_trans_fast_port(t16);
    goto LAB2;

LAB7:    t21 = (t0 + 7310);
    t26 = (t0 + 5072);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memcpy(t30, t21, 7U);
    xsi_driver_first_trans_fast_port(t26);
    goto LAB2;

LAB9:    t31 = (t0 + 7317);
    t36 = (t0 + 5072);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    memcpy(t40, t31, 7U);
    xsi_driver_first_trans_fast_port(t36);
    goto LAB2;

LAB11:    t41 = (t0 + 7324);
    t46 = (t0 + 5072);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    memcpy(t50, t41, 7U);
    xsi_driver_first_trans_fast_port(t46);
    goto LAB2;

LAB13:    t51 = (t0 + 7331);
    t56 = (t0 + 5072);
    t57 = (t56 + 56U);
    t58 = *((char **)t57);
    t59 = (t58 + 56U);
    t60 = *((char **)t59);
    memcpy(t60, t51, 7U);
    xsi_driver_first_trans_fast_port(t56);
    goto LAB2;

LAB15:    t61 = (t0 + 7338);
    t66 = (t0 + 5072);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    memcpy(t70, t61, 7U);
    xsi_driver_first_trans_fast_port(t66);
    goto LAB2;

LAB17:    t71 = (t0 + 7345);
    t76 = (t0 + 5072);
    t77 = (t76 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    memcpy(t80, t71, 7U);
    xsi_driver_first_trans_fast_port(t76);
    goto LAB2;

LAB19:    t81 = (t0 + 7352);
    t86 = (t0 + 5072);
    t87 = (t86 + 56U);
    t88 = *((char **)t87);
    t89 = (t88 + 56U);
    t90 = *((char **)t89);
    memcpy(t90, t81, 7U);
    xsi_driver_first_trans_fast_port(t86);
    goto LAB2;

LAB22:    goto LAB2;

}


extern void work_a_3007137180_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3007137180_3212880686_p_0,(void *)work_a_3007137180_3212880686_p_1,(void *)work_a_3007137180_3212880686_p_2,(void *)work_a_3007137180_3212880686_p_3};
	xsi_register_didat("work_a_3007137180_3212880686", "isim/cont_test_isim_beh.exe.sim/work/a_3007137180_3212880686.didat");
	xsi_register_executes(pe);
}
